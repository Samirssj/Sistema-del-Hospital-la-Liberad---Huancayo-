import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scheduler import PROCESOS, fcfs, sjf, round_robin
import copy

COLORES = {
    "P1": "#c0392b", "P2": "#2980b9", "P3": "#c0392b", "P4": "#2980b9",
    "P5": "#8e44ad", "P6": "#16a085", "P7": "#c0392b", "P8": "#2980b9",
    "P9": "#7f8c8d", "P10": "#2980b9",
}

def plot_gantt(ejecucion, titulo, filename):
    fig, ax = plt.subplots(figsize=(9, 2.6))
    for pid, ini, fin in ejecucion:
        ax.barh(0, fin - ini, left=ini, height=0.6,
                color=COLORES.get(pid, "#34495e"), edgecolor="white")
        ax.text((ini + fin) / 2, 0, pid, ha="center", va="center",
                color="white", fontsize=9, fontweight="bold")
    ax.set_yticks([])
    ax.set_xlabel("Tiempo (unidades)", fontsize=10)
    ax.set_title(titulo, fontsize=12, fontweight="bold", color="#1F3864")
    ax.set_xlim(0, max(f for _, _, f in ejecucion) + 1)
    for spine in ["top", "right", "left"]:
        ax.spines[spine].set_visible(False)
    plt.tight_layout()
    plt.savefig(filename, dpi=150)
    plt.close()

ejecucion_fcfs, _ = fcfs(copy.deepcopy(PROCESOS))
ejecucion_sjf, _ = sjf(copy.deepcopy(PROCESOS))

plot_gantt(ejecucion_fcfs, "Diagrama de Gantt - FCFS", "gantt_fcfs.png")
plot_gantt(ejecucion_sjf, "Diagrama de Gantt - SJF", "gantt_sjf.png")
print("imagenes generadas")
