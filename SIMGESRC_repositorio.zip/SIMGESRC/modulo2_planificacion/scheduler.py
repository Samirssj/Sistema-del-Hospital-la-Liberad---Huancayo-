"""
SIMGESRC - Modulo 2: Simulador de Planificacion de Procesos
Escenario: Hospital II-1 La Libertad - Huancayo, Junin
Algoritmos implementados: FCFS, SJF (no apropiativo), Round Robin (quantum=4)

Autor: Grupo SIMGESRC (Castro Perez, Ortega Colqui, Mosquera Quispe, Rojas Tamara)
Universidad Peruana Los Andes - Sistemas Operativos 2026-I
"""

import copy

# ---------------------------------------------------------------------------
# 1. CARGA DE TRABAJO: 10 procesos representativos del sistema hospitalario
#    (llegadas no simultaneas, ráfagas estimadas en "unidades de tiempo" de CPU)
# ---------------------------------------------------------------------------
PROCESOS = [
    # pid, nombre,                          llegada, rafaga, prioridad(1=alta)
    ("P1",  "Triaje - Emergencia politraumatizado", 0, 3, 1),
    ("P2",  "Registro/Admision paciente consulta",  0, 5, 3),
    ("P3",  "Monitoreo signos vitales (UCI)",        1, 2, 1),
    ("P4",  "Consulta medicina general",             2, 6, 3),
    ("P5",  "Programacion cirugia mediana complej.", 3, 8, 2),
    ("P6",  "Dispensacion de farmacia",               4, 4, 3),
    ("P7",  "Emergencia - shock anafilactico",        5, 2, 1),
    ("P8",  "Actualizacion historia clinica (BD)",    6, 3, 3),
    ("P9",  "Reporte SIS/DIRESA (batch nocturno)",    7, 9, 4),
    ("P10", "Consulta obstetricia - control prenatal",8, 4, 3),
]


def imprimir_gantt(nombre_algo, ejecucion):
    """Imprime un diagrama de Gantt en texto a partir de la lista de tramos (pid, inicio, fin)."""
    print(f"\nDiagrama de Gantt - {nombre_algo}")
    barra = "|"
    for pid, ini, fin in ejecucion:
        barra += f" {pid} ({ini}-{fin}) |"
    print(barra)


def metricas(procesos, finalizacion):
    """Calcula Waiting Time, Turnaround Time, Response Time y throughput."""
    filas = []
    total_wt = total_tat = total_rt = 0
    for pid, nombre, llegada, rafaga, prio in procesos:
        fin = finalizacion[pid]["fin"]
        inicio_resp = finalizacion[pid]["primer_inicio"]
        tat = fin - llegada                    # Turnaround Time
        wt = tat - rafaga                       # Waiting Time
        rt = inicio_resp - llegada               # Response Time
        total_wt += wt
        total_tat += tat
        total_rt += rt
        filas.append((pid, nombre, llegada, rafaga, fin, tat, wt, rt))

    n = len(procesos)
    makespan = max(f["fin"] for f in finalizacion.values())
    throughput = n / makespan
    return filas, total_wt / n, total_tat / n, total_rt / n, throughput


def reporte(nombre_algo, filas, avg_wt, avg_tat, avg_rt, throughput):
    print(f"\n=== Metricas - {nombre_algo} ===")
    print(f"{'PID':4}{'Llegada':9}{'Rafaga':8}{'Fin':6}{'TAT':6}{'WT':6}{'RT':6}")
    for pid, nombre, llegada, rafaga, fin, tat, wt, rt in filas:
        print(f"{pid:4}{llegada:9}{rafaga:8}{fin:6}{tat:6}{wt:6}{rt:6}")
    print(f"-> Avg Waiting Time   : {avg_wt:.2f}")
    print(f"-> Avg Turnaround Time: {avg_tat:.2f}")
    print(f"-> Avg Response Time  : {avg_rt:.2f}")
    print(f"-> Throughput         : {throughput:.3f} procesos/unidad de tiempo")


# ---------------------------------------------------------------------------
# 2. ALGORITMO FCFS (First Come, First Served)
# ---------------------------------------------------------------------------
def fcfs(procesos):
    cola = sorted(procesos, key=lambda p: p[2])  # ordenar por llegada
    reloj = 0
    ejecucion = []
    finalizacion = {}
    for pid, nombre, llegada, rafaga, prio in cola:
        inicio = max(reloj, llegada)
        fin = inicio + rafaga
        ejecucion.append((pid, inicio, fin))
        finalizacion[pid] = {"fin": fin, "primer_inicio": inicio}
        reloj = fin
    return ejecucion, finalizacion


# ---------------------------------------------------------------------------
# 3. ALGORITMO SJF (Shortest Job First, no apropiativo)
# ---------------------------------------------------------------------------
def sjf(procesos):
    pendientes = sorted(procesos, key=lambda p: p[2])
    reloj = 0
    ejecucion = []
    finalizacion = {}
    listos = []
    restantes = list(pendientes)

    while restantes or listos:
        while restantes and restantes[0][2] <= reloj:
            listos.append(restantes.pop(0))
        if not listos:
            reloj = restantes[0][2]
            continue
        listos.sort(key=lambda p: p[3])  # menor rafaga primero
        pid, nombre, llegada, rafaga, prio = listos.pop(0)
        inicio = max(reloj, llegada)
        fin = inicio + rafaga
        ejecucion.append((pid, inicio, fin))
        finalizacion[pid] = {"fin": fin, "primer_inicio": inicio}
        reloj = fin
    return ejecucion, finalizacion


# ---------------------------------------------------------------------------
# 4. ALGORITMO ROUND ROBIN (quantum = 4)
# ---------------------------------------------------------------------------
def round_robin(procesos, quantum=4):
    restantes = {p[0]: p[3] for p in procesos}
    orden = sorted(procesos, key=lambda p: p[2])
    reloj = 0
    cola = []
    ejecucion = []
    finalizacion = {}
    primer_inicio = {}
    idx = 0
    n = len(orden)

    # agregar procesos que ya llegaron en t=0
    while idx < n and orden[idx][2] <= reloj:
        cola.append(orden[idx])
        idx += 1

    while cola:
        pid, nombre, llegada, rafaga, prio = cola.pop(0)
        if pid not in primer_inicio:
            primer_inicio[pid] = max(reloj, llegada)
        inicio = reloj
        ejecutar = min(quantum, restantes[pid])
        fin = inicio + ejecutar
        ejecucion.append((pid, inicio, fin))
        restantes[pid] -= ejecutar
        reloj = fin

        # incorporar nuevas llegadas durante este tramo
        while idx < n and orden[idx][2] <= reloj:
            cola.append(orden[idx])
            idx += 1

        if restantes[pid] > 0:
            cola.append((pid, nombre, llegada, restantes[pid], prio))
        else:
            finalizacion[pid] = {"fin": fin, "primer_inicio": primer_inicio[pid]}

    return ejecucion, finalizacion


# ---------------------------------------------------------------------------
# 5. EJECUCION Y COMPARATIVA
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    resultados_resumen = []

    for nombre_algo, func in [("FCFS", fcfs), ("SJF", sjf), ("Round Robin (q=4)", round_robin)]:
        ejecucion, finalizacion = func(copy.deepcopy(PROCESOS))
        filas, avg_wt, avg_tat, avg_rt, throughput = metricas(PROCESOS, finalizacion)
        reporte(nombre_algo, filas, avg_wt, avg_tat, avg_rt, throughput)
        imprimir_gantt(nombre_algo, ejecucion)
        resultados_resumen.append((nombre_algo, avg_wt, avg_tat, avg_rt, throughput))

    print("\n\n=== COMPARATIVA FINAL ===")
    print(f"{'Algoritmo':20}{'AWT':8}{'ATAT':8}{'ART':8}{'Throughput':10}")
    for nombre_algo, avg_wt, avg_tat, avg_rt, throughput in resultados_resumen:
        print(f"{nombre_algo:20}{avg_wt:<8.2f}{avg_tat:<8.2f}{avg_rt:<8.2f}{throughput:<10.3f}")
