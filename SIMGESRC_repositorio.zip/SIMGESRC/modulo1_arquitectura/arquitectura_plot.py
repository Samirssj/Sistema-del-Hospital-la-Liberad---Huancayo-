import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

fig, ax = plt.subplots(figsize=(9.5, 6))
ax.set_xlim(0, 10)
ax.set_ylim(0, 10)
ax.axis("off")

def box(x, y, w, h, text, color="#DCE6F1", edge="#1F3864", fontsize=9, fontweight="normal"):
    r = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.08",
                        linewidth=1.4, edgecolor=edge, facecolor=color)
    ax.add_patch(r)
    ax.text(x + w/2, y + h/2, text, ha="center", va="center",
            fontsize=fontsize, fontweight=fontweight, color="#1F3864", wrap=True)

def arrow(x1, y1, x2, y2):
    a = FancyArrowPatch((x1, y1), (x2, y2), arrowstyle="-|>", mutation_scale=14,
                         color="#1F3864", linewidth=1.2)
    ax.add_patch(a)

# Capa clientes
box(0.4, 8.4, 2.0, 1.0, "Terminales\nTriaje / Emergencia", "#F4CCCC", fontsize=8)
box(2.7, 8.4, 2.0, 1.0, "Estaciones\nAdmision / Consultorios", "#DCE6F1", fontsize=8)
box(5.0, 8.4, 2.0, 1.0, "App movil\nSensores UCI", "#F4CCCC", fontsize=8)
box(7.3, 8.4, 2.1, 1.0, "Farmacia / Reportes\n(SIS-DIRESA)", "#DCE6F1", fontsize=8)

arrow(1.4, 8.4, 4.7, 6.9)
arrow(3.7, 8.4, 4.9, 6.9)
arrow(6.0, 8.4, 5.1, 6.9)
arrow(8.35, 8.4, 5.3, 6.9)

# Servidor central / SO
box(3.3, 5.8, 3.4, 1.1, "SERVIDOR CENTRAL\nKernel hibrido (Linux, modulos RT)", "#1F3864", fontsize=8.5, fontweight="bold")
ax.text(5.0, 6.35, "", color="white")
ax.texts[-1].set_visible(False)

# Corregir texto blanco sobre fondo oscuro
ax.patches[-1].set_facecolor("#1F3864")
ax.texts[4].set_color("white")

# Modulos del kernel
box(0.6, 4.2, 2.5, 1.0, "Planificador\n(Scheduler)\nFCFS / SJF / RR", "#E2EFD9", fontsize=8)
box(3.35, 4.2, 2.5, 1.0, "Sincronizacion\n(Mutex / Semaforos)", "#E2EFD9", fontsize=8)
box(6.1, 4.2, 2.5, 1.0, "Gestion de Memoria\n(Paginacion)", "#E2EFD9", fontsize=8)

arrow(4.4, 5.8, 1.85, 5.2)
arrow(5.0, 5.8, 4.6, 5.2)
arrow(5.6, 5.8, 7.35, 5.2)

# Capa de datos
box(1.0, 2.4, 3.5, 1.0, "Base de Datos\nHistorias clinicas / Citas (PostgreSQL)", "#FFF2CC", fontsize=8)
box(5.0, 2.4, 3.7, 1.0, "Almacenamiento\nSSD RAID 10 - Backups", "#FFF2CC", fontsize=8)

arrow(2.75, 4.2, 2.75, 3.4)
arrow(6.85, 4.2, 6.85, 3.4)

# Recursos compartidos
box(2.0, 0.6, 5.8, 1.0, "Recursos compartidos: Salas de consulta, equipos de\ndiagnostico, camas UCI, quirofanos", "#EAD1DC", fontsize=8)
arrow(5.0, 2.4, 5.0, 1.6)

ax.set_title("Arquitectura propuesta - Sistema de Gestion Hospital II-1 La Libertad",
             fontsize=12, fontweight="bold", color="#1F3864", pad=14)

plt.tight_layout()
plt.savefig("arquitectura.png", dpi=150)
print("listo")
