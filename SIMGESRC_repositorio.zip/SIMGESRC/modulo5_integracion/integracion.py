"""
SIMGESRC - Modulo 5: Integracion, Analisis y Propuesta de Mejora
Escenario: Hospital II-1 La Libertad - Huancayo, Junin

Integra:
  - Modulo 2: planificador de procesos (se reutiliza el algoritmo SJF,
    recomendado en el avance parcial por su mejor AWT/ATAT).
  - Modulo 3: sincronizacion de acceso a recursos compartidos (camas UCI)
    mediante un semaforo.
  - Modulo 4: asignacion de memoria a cada proceso mediante paginacion.

El sistema integrado "lanza" cada proceso de la carga de trabajo, le asigna
memoria, y si requiere una cama UCI, la solicita de forma sincronizada.
Al final se miden: throughput, tiempo de respuesta promedio, uso de memoria,
uso estimado de CPU y numero de conflictos de sincronizacion evitados.
"""

import threading
import time
import sys
import os

sys.path.append(os.path.join(os.path.dirname(__file__), "..", "modulo2_planificacion"))
sys.path.append(os.path.join(os.path.dirname(__file__), "..", "modulo4_memoria"))

from scheduler import PROCESOS, sjf, metricas          # Modulo 2
from memoria import MemoriaPaginada                     # Modulo 4

# Requerimiento de memoria por proceso (MB), alineado al Modulo 4
MEMORIA_POR_PROCESO = {
    "P1": 20, "P2": 26, "P3": 15, "P4": 33, "P5": 39,
    "P6": 22, "P7": 20, "P8": 18, "P9": 64, "P10": 28,
}
# Procesos que requieren una cama UCI (recurso compartido y escaso)
REQUIERE_CAMA_UCI = {"P1", "P3", "P7"}
CAMAS_UCI_DISPONIBLES = 2  # solo 2 camas libres en el turno simulado


def sistema_integrado():
    print("=" * 78)
    print("SISTEMA INTEGRADO SIMGESRC - Ejecucion con carga de trabajo real")
    print("=" * 78)

    # 1) Planificacion (Modulo 2) -----------------------------------------
    ejecucion, finalizacion = sjf([p for p in PROCESOS])
    filas, avg_wt, avg_tat, avg_rt, throughput = metricas(PROCESOS, finalizacion)
    print("\n[1] Planificador SJF ejecutado. Orden de despacho:")
    for pid, ini, fin in ejecucion:
        print(f"    {pid}: {ini} -> {fin}")

    # 2) Memoria (Modulo 4) --------------------------------------------
    mem = MemoriaPaginada(256, tamano_marco=4)
    memoria_rechazada = 0
    memoria_usada_pico = 0
    print("\n[2] Asignacion de memoria por proceso (paginacion):")
    for pid, ini, fin in ejecucion:
        tam = MEMORIA_POR_PROCESO[pid]
        resultado = mem.asignar(pid, tam)
        if resultado is False:
            memoria_rechazada += 1
            print(f"    {pid}: RECHAZADO por falta de memoria")
        else:
            marcos_usados = sum(1 for m in mem.marcos if m is not None) * mem.tamano_marco
            memoria_usada_pico = max(memoria_usada_pico, marcos_usados)
            print(f"    {pid}: {tam} MB asignados ({len(mem.tabla(pid))} paginas)")
        mem.liberar(pid)  # el proceso libera memoria al terminar su rafaga (simplificacion)

    # 3) Sincronizacion de camas UCI (Modulo 3) --------------------------
    print("\n[3] Solicitud sincronizada de camas UCI (semaforo, cupo=2):")
    semaforo_camas = threading.Semaphore(CAMAS_UCI_DISPONIBLES)
    conflictos_evitados = 0
    lock_contador = threading.Lock()
    resultados_uci = []

    def solicitar_cama(pid):
        nonlocal conflictos_evitados
        adquirido = semaforo_camas.acquire(timeout=0.15)
        if adquirido:
            print(f"    {pid}: cama UCI asignada")
            time.sleep(0.4)  # tiempo de uso simulado (mayor que el timeout de espera)
            semaforo_camas.release()
            resultados_uci.append((pid, True))
        else:
            with lock_contador:
                conflictos_evitados += 1
            print(f"    {pid}: SIN cama disponible -> en espera/derivado (evitado por semaforo, no hubo sobre-asignacion)")
            resultados_uci.append((pid, False))

    hilos_uci = [threading.Thread(target=solicitar_cama, args=(pid,)) for pid in REQUIERE_CAMA_UCI]
    for h in hilos_uci: h.start()
    for h in hilos_uci: h.join()

    # 4) Metricas finales del sistema integrado --------------------------
    cpu_uso_estimado = sum(p[3] for p in PROCESOS) / (max(f for _, _, f in ejecucion)) * 100

    print("\n" + "=" * 78)
    print("METRICAS DEL SISTEMA INTEGRADO")
    print("=" * 78)
    print(f"Throughput total            : {throughput:.3f} procesos/unidad de tiempo")
    print(f"Tiempo de respuesta promedio : {avg_rt:.2f} unidades")
    print(f"Uso de CPU estimado          : {cpu_uso_estimado:.1f}%")
    print(f"Uso de memoria pico           : {memoria_usada_pico} MB de 256 MB ({memoria_usada_pico/256*100:.1f}%)")
    print(f"Procesos con memoria rechazada: {memoria_rechazada}")
    print(f"Conflictos de UCI evitados por el semaforo: {conflictos_evitados} "
          f"(de {len(REQUIERE_CAMA_UCI)} solicitudes, cupo={CAMAS_UCI_DISPONIBLES})")

    # 5) Bottlenecks detectados -------------------------------------------
    print("\n" + "=" * 78)
    print("BOTTLENECKS DETECTADOS")
    print("=" * 78)
    print("""
1) Camas UCI: con solo 2 camas disponibles y 3 procesos criticos (triaje,
   monitoreo UCI, emergencia) compitiendo, el semaforo genera espera
   evitando sobre-asignacion, pero produce una cola de espera para
   emergencias -> bottleneck real de infraestructura, no solo de software.

2) Proceso batch "Reporte SIS/DIRESA" (P9, 64 MB, rafaga 9): al ser el mas
   pesado en CPU y memoria, si llega durante horas pico compite por marcos
   de memoria con procesos criticos, elevando el tiempo de respuesta de
   estos ultimos si no se aisla en una cola de baja prioridad.
""")

    print("=" * 78)
    print("PROPUESTA DE OPTIMIZACION")
    print("=" * 78)
    print("""
- Scheduler: migrar de SJF puro a MLFQ, reservando la cola de mayor
  prioridad exclusivamente para procesos con prioridad=1 (triaje,
  monitoreo UCI, emergencias), evitando que un proceso largo bloquee la
  atencion critica. Beneficio estimado: reduccion de ~30% en el Response
  Time de los procesos de emergencia (basado en la diferencia observada
  entre SJF y Round Robin en el Modulo 2, ART 11.00 vs 11.40 ya cercanos,
  pero con aislamiento total de la cola critica se proyecta ART < 5).

- Memoria: reservar estaticamente un pool de marcos exclusivo para
  procesos criticos (p.ej. 32 MB reservados) para que el proceso batch
  P9 nunca pueda saturar la memoria disponible para triaje/UCI.

- Sincronizacion: reemplazar el semaforo simple de camas UCI por una cola
  de prioridad (los pacientes de mayor gravedad desplazan la espera de
  los de menor gravedad), reduciendo el tiempo de espera critico aunque
  el recurso fisico (2 camas) no aumente.
""")


if __name__ == "__main__":
    sistema_integrado()
