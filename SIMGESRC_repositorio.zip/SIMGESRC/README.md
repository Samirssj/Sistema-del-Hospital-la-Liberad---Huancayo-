# SIMGESRC – Sistema de Gestión de Recursos Computacionales

**Trabajo Final Integrador – Sistemas Operativos (Cód. 33218A) | VII Ciclo | UPLA 2026-I**
**Docente:** Msc. Jaime Antonio Huaytalla Pariona

## Escenario elegido

**Escenario A – Hospital Regional**, tomando como organización de referencia el
**Hospital II-1 La Libertad**, ubicado en la Cooperativa Santa Isabel, Huancayo (Junín).

## Integrantes del grupo

| Integrante | Módulo a cargo |
|---|---|
| Juan Daniel Castro Pérez | Módulo 1 – Arquitectura y Tipo de SO |
| Victor Rubén Ortega Colqui | Módulo 2 – Gestión de Procesos y Planificación |
| Daniel Nemías Mosquera Quispe | Módulo 3 – Sincronización y Concurrencia |
| Samir Sabdiel Rojas Tamara | Módulo 4 – Gestión de Memoria |
| Todos | Módulo 5 – Integración, Análisis y Propuesta de Mejora |

## Estructura del repositorio

```
SIMGESRC/
├── README.md                      <- este archivo
├── requirements.txt                <- dependencias de Python
├── modulo1_arquitectura/
│   ├── arquitectura.png            <- diagrama de arquitectura del sistema
│   └── arquitectura_plot.py        <- script que genera el diagrama
├── modulo2_planificacion/
│   ├── scheduler.py                <- simulador FCFS, SJF y Round Robin
│   ├── gantt_plot.py                <- genera los diagramas de Gantt (PNG)
│   ├── gantt_fcfs.png
│   └── gantt_sjf.png
├── modulo3_sincronizacion/
│   ├── sincronizacion.py           <- race condition, deadlock y su prevención
│   └── salida_ejemplo.txt          <- salida de una ejecución de referencia
├── modulo4_memoria/
│   ├── memoria.py                  <- partición dinámica (First-Fit) y paginación
│   └── salida_ejemplo.txt
├── modulo5_integracion/
│   ├── integracion.py              <- integra los módulos 2, 3 y 4
│   └── salida_ejemplo.txt
└── docs/
    └── (aquí van el informe técnico final E3 y las presentaciones)
```

## Cómo ejecutar cada módulo

Requiere Python 3.10+ y las dependencias de `requirements.txt`.

```bash
pip install -r requirements.txt

# Módulo 2 – simulador de planificación
python modulo2_planificacion/scheduler.py
python modulo2_planificacion/gantt_plot.py      # genera las imágenes de Gantt

# Módulo 3 – sincronización, race condition y deadlock
python modulo3_sincronizacion/sincronizacion.py

# Módulo 4 – gestión de memoria
python modulo4_memoria/memoria.py

# Módulo 5 – sistema integrado (usa scheduler.py y memoria.py)
python modulo5_integracion/integracion.py
```

## Resumen de cada módulo

### Módulo 1 – Arquitectura y Tipo de SO
Sistema operativo híbrido (tiempo compartido + soporte de tiempo real blando),
basado en un kernel Linux modular con extensión PREEMPT_RT. Arquitectura
hardware propuesta: 2 CPU de 16 núcleos, 64 GB RAM ECC, SSD NVMe RAID 10.

### Módulo 2 – Gestión de Procesos y Planificación
7 tipos de procesos caracterizados (triaje, admisión, monitoreo UCI, consulta,
cirugía, farmacia, reportes). Simulador con FCFS, SJF y Round Robin sobre una
carga de 10 procesos. **Resultado:** SJF obtuvo el mejor AWT (11.00) y ATAT
(15.60); Round Robin el mejor ART (11.40).

### Módulo 3 – Sincronización y Concurrencia
Dos secciones críticas: reserva de camas UCI (con `threading.Lock`) y
asignación conjunta de quirófano + anestesia (con `threading.Lock` por
recurso). Se demuestra una condición de carrera real (sobre-reserva de camas)
y un deadlock real por orden inverso de adquisición de recursos, junto con su
solución mediante ordenamiento global de recursos.

### Módulo 4 – Gestión de Memoria
Compara partición dinámica (First-Fit) vs. paginación simple (marco = 4 MB)
sobre 18 operaciones de asignación/liberación. La paginación resultó más
adecuada por su fragmentación interna baja y predecible frente a la
fragmentación externa de la partición dinámica.

### Módulo 5 – Integración, Análisis y Propuesta de Mejora
Ejecuta el planificador SJF, asigna memoria paginada a cada proceso y
sincroniza el acceso a las camas UCI (2 camas, 3 solicitudes críticas)
mediante un semáforo. Se identifican 2 bottlenecks (camas UCI y el proceso
batch de reportes) y se propone migrar a un scheduler MLFQ con cola
reservada para procesos críticos.

## Declaración de uso de IA

Se utilizó IA generativa (Claude, Anthropic) como apoyo para la redacción de
justificaciones técnicas, la generación de diagramas y el andamiaje inicial
del código de simulación. Todo el código fue revisado, ejecutado y validado
por el grupo antes de su entrega, cumpliendo con el límite del 20% establecido
en las normas de integridad académica del curso.
