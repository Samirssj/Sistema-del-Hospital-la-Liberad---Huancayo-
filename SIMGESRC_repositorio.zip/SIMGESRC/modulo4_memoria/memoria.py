"""
SIMGESRC - Modulo 4: Gestion de Memoria
Escenario: Hospital II-1 La Libertad - Huancayo, Junin

Se implementan y comparan DOS esquemas de asignacion de memoria:
  1) Particion dinamica (variable) con algoritmo First-Fit.
  2) Paginacion simple con marcos de tamano fijo.

Se simulan >= 15 operaciones de asignacion/liberacion y se calcula la
fragmentacion resultante en cada esquema.
"""

# ---------------------------------------------------------------------------
# Estimacion de memoria requerida por proceso (codigo + datos + heap + stack)
# ---------------------------------------------------------------------------
PROCESOS_MEMORIA = [
    # nombre, codigo(MB), datos(MB), heap(MB), stack(MB)
    ("Triaje/Emergencia",        8,  4,  6,  2),
    ("Registro/Admision",       10,  6,  8,  2),
    ("Monitoreo UCI",            6,  3,  4,  2),
    ("Consulta medica",         12,  8, 10,  3),
    ("Programacion cirugia",    14, 10, 12,  3),
    ("Farmacia",                 9,  5,  6,  2),
    ("Reporte SIS/DIRESA",      20, 15, 25,  4),
]

def tabla_requerimientos():
    print("=" * 78)
    print("Requerimiento de memoria estimado por proceso (MB)")
    print("=" * 78)
    print(f"{'Proceso':24}{'Codigo':8}{'Datos':8}{'Heap':8}{'Stack':8}{'Total':8}")
    total_global = 0
    for nombre, cod, dat, heap, stack in PROCESOS_MEMORIA:
        total = cod + dat + heap + stack
        total_global += total
        print(f"{nombre:24}{cod:<8}{dat:<8}{heap:<8}{stack:<8}{total:<8}")
    print(f"\nTotal estimado (procesos base, sin contar el SO): {total_global} MB")
    return total_global


# ---------------------------------------------------------------------------
# ESQUEMA 1: PARTICION DINAMICA - First Fit
# ---------------------------------------------------------------------------
class MemoriaParticionDinamica:
    def __init__(self, tamano_total):
        # Lista de bloques: (inicio, tamano, ocupado_por or None)
        self.bloques = [{"inicio": 0, "tamano": tamano_total, "proceso": None}]
        self.tamano_total = tamano_total

    def asignar(self, proceso, tamano):
        for b in self.bloques:
            if b["proceso"] is None and b["tamano"] >= tamano:
                sobrante = b["tamano"] - tamano
                b["proceso"] = proceso
                b["tamano"] = tamano
                if sobrante > 0:
                    idx = self.bloques.index(b)
                    nuevo = {"inicio": b["inicio"] + tamano, "tamano": sobrante, "proceso": None}
                    self.bloques.insert(idx + 1, nuevo)
                return True
        return False  # no hay hueco suficiente (fragmentacion externa)

    def liberar(self, proceso):
        for b in self.bloques:
            if b["proceso"] == proceso:
                b["proceso"] = None
        self._fusionar_libres()

    def _fusionar_libres(self):
        i = 0
        while i < len(self.bloques) - 1:
            actual, sig = self.bloques[i], self.bloques[i + 1]
            if actual["proceso"] is None and sig["proceso"] is None:
                actual["tamano"] += sig["tamano"]
                del self.bloques[i + 1]
            else:
                i += 1

    def fragmentacion_externa(self):
        return sum(b["tamano"] for b in self.bloques if b["proceso"] is None)

    def mapa(self):
        print("\nMapa de particiones actual:")
        for b in self.bloques:
            estado = b["proceso"] if b["proceso"] else "LIBRE"
            print(f"  [{b['inicio']:4} - {b['inicio']+b['tamano']-1:4}]  {b['tamano']:4} MB  -> {estado}")


# ---------------------------------------------------------------------------
# ESQUEMA 2: PAGINACION SIMPLE (marcos de tamano fijo)
# ---------------------------------------------------------------------------
class MemoriaPaginada:
    def __init__(self, tamano_total, tamano_marco=4):
        self.tamano_marco = tamano_marco
        self.n_marcos = tamano_total // tamano_marco
        self.marcos = [None] * self.n_marcos   # None = libre, o nombre del proceso
        self.tabla_paginas = {}                # proceso -> lista de marcos asignados

    def asignar(self, proceso, tamano):
        n_paginas = -(-tamano // self.tamano_marco)  # techo (ceil)
        libres = [i for i, m in enumerate(self.marcos) if m is None]
        if len(libres) < n_paginas:
            return False
        marcos_asignados = libres[:n_paginas]
        for m in marcos_asignados:
            self.marcos[m] = proceso
        self.tabla_paginas[proceso] = marcos_asignados
        # fragmentacion interna: espacio sobrante en el ultimo marco
        interna = n_paginas * self.tamano_marco - tamano
        return interna

    def liberar(self, proceso):
        if proceso in self.tabla_paginas:
            for m in self.tabla_paginas[proceso]:
                self.marcos[m] = None
            del self.tabla_paginas[proceso]

    def tabla(self, proceso):
        return self.tabla_paginas.get(proceso, [])

    def mapa(self, max_marcos_mostrar=40):
        print("\nMapa de marcos (paginacion) [primeros %d marcos]:" % max_marcos_mostrar)
        for i, m in enumerate(self.marcos[:max_marcos_mostrar]):
            estado = m if m else "-"
            print(f"  Marco {i:3}: {estado}")


# ---------------------------------------------------------------------------
# SIMULACION: 15+ operaciones de asignacion/liberacion
# ---------------------------------------------------------------------------
OPERACIONES = [
    ("asignar", "Triaje/Emergencia", 20),
    ("asignar", "Registro/Admision", 26),
    ("asignar", "Monitoreo UCI", 15),
    ("asignar", "Consulta medica", 33),
    ("liberar", "Registro/Admision", None),
    ("asignar", "Programacion cirugia", 39),
    ("asignar", "Farmacia", 22),
    ("liberar", "Triaje/Emergencia", None),
    ("asignar", "Reporte SIS/DIRESA", 64),
    ("asignar", "Consulta obstetricia", 28),
    ("liberar", "Monitoreo UCI", None),
    ("asignar", "Triaje/Emergencia", 20),   # nueva instancia del proceso
    ("liberar", "Consulta medica", None),
    ("asignar", "Actualizacion historia", 18),
    ("liberar", "Farmacia", None),
    ("asignar", "Monitoreo UCI", 15),
    ("liberar", "Reporte SIS/DIRESA", None),
    ("asignar", "Dispensacion urgente", 12),
]  # 18 operaciones (>= 15 exigidas)


def simular_particion_dinamica():
    print("\n" + "=" * 78)
    print("ESQUEMA 1: PARTICION DINAMICA (First-Fit) - Memoria total: 256 MB")
    print("=" * 78)
    mem = MemoriaParticionDinamica(256)
    for i, (accion, proceso, tam) in enumerate(OPERACIONES, 1):
        if accion == "asignar":
            ok = mem.asignar(proceso, tam)
            estado = "OK" if ok else "RECHAZADO (sin hueco suficiente)"
            print(f"  Op.{i:2} ASIGNAR  {proceso:24} {tam:3} MB -> {estado}")
        else:
            mem.liberar(proceso)
            print(f"  Op.{i:2} LIBERAR  {proceso}")

    mem.mapa()
    frag = mem.fragmentacion_externa()
    print(f"\nFragmentacion externa final: {frag} MB repartidos en "
          f"{sum(1 for b in mem.bloques if b['proceso'] is None)} huecos libres.")
    return frag


def simular_paginacion():
    print("\n" + "=" * 78)
    print("ESQUEMA 2: PAGINACION SIMPLE (marco = 4 MB) - Memoria total: 256 MB")
    print("=" * 78)
    mem = MemoriaPaginada(256, tamano_marco=4)
    frag_interna_total = 0
    for i, (accion, proceso, tam) in enumerate(OPERACIONES, 1):
        if accion == "asignar":
            resultado = mem.asignar(proceso, tam)
            if resultado is False:
                print(f"  Op.{i:2} ASIGNAR  {proceso:24} {tam:3} MB -> RECHAZADO (sin marcos libres)")
            else:
                frag_interna_total += resultado
                print(f"  Op.{i:2} ASIGNAR  {proceso:24} {tam:3} MB -> OK "
                      f"({len(mem.tabla(proceso))} paginas, frag. interna {resultado} MB)")
        else:
            mem.liberar(proceso)
            print(f"  Op.{i:2} LIBERAR  {proceso}")

    print(f"\nTabla de paginas (estado intermedio) del proceso 'Reporte SIS/DIRESA' "
          f"si aun estuviera activo, o del ultimo proceso asignado:")
    ultimo = [p for a, p, t in OPERACIONES if a == "asignar"][-1]
    print(f"  {ultimo} -> marcos {mem.tabla(ultimo)}")
    mem.mapa(max_marcos_mostrar=20)
    print(f"\nFragmentacion interna acumulada: {frag_interna_total} MB")
    return frag_interna_total


if __name__ == "__main__":
    tabla_requerimientos()
    frag_ext = simular_particion_dinamica()
    frag_int = simular_paginacion()

    print("\n" + "=" * 78)
    print("COMPARATIVA DE ESQUEMAS")
    print("=" * 78)
    print(f"Particion dinamica (First-Fit) -> fragmentacion EXTERNA: {frag_ext} MB")
    print(f"Paginacion (marco=4MB)         -> fragmentacion INTERNA: {frag_int} MB")
    print("""
Recomendacion: para el Hospital II-1 La Libertad se recomienda PAGINACION,
porque su fragmentacion (interna) es pequena y predecible por marco, evita
la fragmentacion externa que en particion dinamica puede impedir asignar un
proceso grande (p.ej. el reporte SIS/DIRESA) aun cuando la suma de huecos
libres alcance, y facilita el crecimiento dinamico de procesos como el
monitoreo UCI, que se reinician con frecuencia durante el turno.
""")
