"""
SIMGESRC - Modulo 3: Sincronizacion y Concurrencia
Escenario: Hospital II-1 La Libertad - Huancayo, Junin

Secciones criticas identificadas:
  1) Contador de camas UCI disponibles (recurso compartido por varios hilos
     de "admision/alta" de pacientes).
  2) Asignacion de quirofano + equipo de anestesia (dos recursos que se
     piden en conjunto -> escenario de deadlock).

Este script demuestra:
  A) Race condition SIN sincronizacion vs. SOLUCION con Lock.
  B) Deadlock por orden inverso de adquisicion de recursos y su prevencion
     mediante ordenamiento global de recursos.
  C) Prueba de overhead de sincronizacion con 5+ hilos concurrentes.
"""

import threading
import time

# ---------------------------------------------------------------------------
# A) SECCION CRITICA 1: reserva de camas UCI disponibles
#    Patron TOCTOU (Time-Of-Check-To-Time-Of-Use): cada hilo revisa si hay
#    cupo y luego reserva; si no se sincroniza, varios hilos pueden pasar la
#    verificacion "al mismo tiempo" y sobre-reservar camas que no existen.
# ---------------------------------------------------------------------------
CAMAS_DISPONIBLES = 5
N_HILOS = 20          # 20 solicitudes de cama compitiendo por 5 cupos
ITERACIONES_OVERHEAD = 2000


def solicitar_cama_sin_lock(camas, reservas_exitosas):
    if camas["disponibles"] > 0:      # CHECK
        time.sleep(0.001)              # simula latencia de procesamiento (agrava la ventana de carrera)
        camas["disponibles"] -= 1      # USE (sin proteccion)
        reservas_exitosas.append(1)


def solicitar_cama_con_lock(camas, lock, reservas_exitosas):
    with lock:
        if camas["disponibles"] > 0:
            time.sleep(0.001)
            camas["disponibles"] -= 1
            reservas_exitosas.append(1)


def demo_race_condition():
    print("=" * 70)
    print("A) RACE CONDITION - Reserva de camas UCI (5 camas, 20 solicitudes)")
    print("=" * 70)

    # --- SIN sincronizacion ---
    camas = {"disponibles": CAMAS_DISPONIBLES}
    reservas = []
    hilos = [threading.Thread(target=solicitar_cama_sin_lock, args=(camas, reservas)) for _ in range(N_HILOS)]
    for h in hilos: h.start()
    for h in hilos: h.join()
    print(f"\nSIN Lock  -> camas reservadas: {len(reservas)}  |  camas restantes en el sistema: {camas['disponibles']}")
    if len(reservas) > CAMAS_DISPONIBLES:
        print(f"            *** RACE CONDITION: se sobre-reservaron {len(reservas) - CAMAS_DISPONIBLES} camas que no existen ***")

    # --- CON sincronizacion (mutex) ---
    camas2 = {"disponibles": CAMAS_DISPONIBLES}
    reservas2 = []
    lock = threading.Lock()
    hilos2 = [threading.Thread(target=solicitar_cama_con_lock, args=(camas2, lock, reservas2)) for _ in range(N_HILOS)]
    for h in hilos2: h.start()
    for h in hilos2: h.join()
    print(f"\nCON Lock  -> camas reservadas: {len(reservas2)}  |  camas restantes en el sistema: {camas2['disponibles']}")
    print("            -> exactamente el limite real de camas, sin sobre-reserva.")

    # --- Medicion de overhead con carga intensiva (2000 iteraciones/hilo) ---
    contador = {"v": 0}
    def carga_sin_lock():
        for _ in range(ITERACIONES_OVERHEAD):
            contador["v"] += 1
    def carga_con_lock(lock):
        for _ in range(ITERACIONES_OVERHEAD):
            with lock:
                contador["v"] += 1

    hilos_a = [threading.Thread(target=carga_sin_lock) for _ in range(8)]
    t0 = time.perf_counter()
    for h in hilos_a: h.start()
    for h in hilos_a: h.join()
    dur_sin = time.perf_counter() - t0

    lock2 = threading.Lock()
    hilos_b = [threading.Thread(target=carga_con_lock, args=(lock2,)) for _ in range(8)]
    t0 = time.perf_counter()
    for h in hilos_b: h.start()
    for h in hilos_b: h.join()
    dur_con = time.perf_counter() - t0

    overhead = ((dur_con - dur_sin) / dur_sin) * 100 if dur_sin > 0 else 0
    print(f"\nOverhead de sincronizacion (8 hilos x {ITERACIONES_OVERHEAD} incrementos): "
          f"{dur_sin*1000:.2f} ms sin lock vs {dur_con*1000:.2f} ms con lock  (+{overhead:.1f}%)")
    return dur_sin, dur_con


# ---------------------------------------------------------------------------
# B) SECCION CRITICA 2: asignacion de quirofano + equipo de anestesia
#    -> escenario de DEADLOCK
# ---------------------------------------------------------------------------
quirofano = threading.Lock()
anestesia = threading.Lock()


def cirugia_orden_A_sin_prevencion():
    """Hilo que pide primero quirofano y luego anestesia."""
    with quirofano:
        print("  [Cirugia programada] tomo QUIROFANO, esperando ANESTESIA...")
        time.sleep(0.3)
        with anestesia:
            print("  [Cirugia programada] tomo ANESTESIA. Procede la cirugia.")


def cirugia_orden_B_sin_prevencion():
    """Hilo que pide primero anestesia y luego quirofano (orden invertido -> deadlock)."""
    with anestesia:
        print("  [Cirugia emergencia] tomo ANESTESIA, esperando QUIROFANO...")
        time.sleep(0.3)
        with quirofano:
            print("  [Cirugia emergencia] tomo QUIROFANO. Procede la cirugia.")


def demo_deadlock_potencial():
    print("\n" + "=" * 70)
    print("B) ESCENARIO DE DEADLOCK POTENCIAL - Quirofano + Anestesia")
    print("=" * 70)
    print("(Se ejecuta con timeout para no congelar la demo si ocurre deadlock)\n")

    h1 = threading.Thread(target=cirugia_orden_A_sin_prevencion, daemon=True)
    h2 = threading.Thread(target=cirugia_orden_B_sin_prevencion, daemon=True)
    h1.start(); h2.start()
    h1.join(timeout=2)
    h2.join(timeout=2)
    if h1.is_alive() or h2.is_alive():
        print("\n  *** DEADLOCK CONFIRMADO: ambos hilos quedaron bloqueados "
              "esperando el recurso que el otro ya tomo. ***")
    else:
        print("\n  (En esta corrida no se materializo el deadlock por timing, "
              "pero la condicion de espera circular sigue latente en el diseño.)")


def cirugia_orden_A_con_prevencion(lock_anestesia, lock_quirofano):
    """Estrategia de prevencion: ordenar SIEMPRE la adquisicion de recursos
    (ej. alfabeticamente: anestesia antes que quirofano) para romper la
    espera circular (Coffman condition 'hold and wait en orden distinto')."""
    with lock_anestesia:
        time.sleep(0.05)
        with lock_quirofano:
            print("  [Cirugia programada] adquirio recursos en orden global (OK)")


def cirugia_orden_B_con_prevencion(lock_anestesia, lock_quirofano):
    with lock_anestesia:
        time.sleep(0.05)
        with lock_quirofano:
            print("  [Cirugia emergencia] adquirio recursos en orden global (OK)")


def demo_prevencion_deadlock():
    print("\n" + "=" * 70)
    print("Estrategia de prevencion aplicada: ORDENAMIENTO GLOBAL DE RECURSOS")
    print("(todo hilo debe pedir 'anestesia' antes que 'quirofano', sin excepcion)")
    print("=" * 70)
    # Se usan locks NUEVOS (independientes de la demo de deadlock anterior,
    # que deja sus locks originales retenidos para siempre por los hilos daemon).
    lock_anestesia = threading.Lock()
    lock_quirofano = threading.Lock()
    h1 = threading.Thread(target=cirugia_orden_A_con_prevencion, args=(lock_anestesia, lock_quirofano), daemon=True)
    h2 = threading.Thread(target=cirugia_orden_B_con_prevencion, args=(lock_anestesia, lock_quirofano), daemon=True)
    h1.start(); h2.start()
    h1.join(timeout=2)
    h2.join(timeout=2)
    print("  -> Ambos hilos finalizaron sin bloqueo mutuo.")


if __name__ == "__main__":
    demo_race_condition()
    demo_deadlock_potencial()
    demo_prevencion_deadlock()
